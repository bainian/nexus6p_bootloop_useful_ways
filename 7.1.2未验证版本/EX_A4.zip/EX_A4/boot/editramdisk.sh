#!/sbin/sh

mkdir /tmp/ramdisk
cp /tmp/boot.img-ramdisk.gz /tmp/ramdisk/
cd /tmp/ramdisk/
/tmp/busybox gunzip -c /tmp/ramdisk/boot.img-ramdisk.gz | /tmp/busybox cpio -i
rm /tmp/ramdisk/boot.img-ramdisk.gz
rm /tmp/boot.img-ramdisk.gz

#Don't force encryption
if  grep -qr forceencrypt /tmp/ramdisk/fstab.angler; then
   sed -i "s/forceencrypt/encryptable/" /tmp/ramdisk/fstab.angler
fi
if  grep -qr forcefdeorfbe /tmp/ramdisk/fstab.angler; then
   sed -i "s/forcefdeorfbe/encryptable/" /tmp/ramdisk/fstab.angler
fi

#Disable dm_verity
if  grep -qr verify=/dev/block/platform/soc.0/f9824900.sdhci/by-name/metadata /tmp/ramdisk/fstab.angler; then
   sed -i "s/\,verify\=\/dev\/block\/platform\/soc\.0\/f9824900\.sdhci\/by\-name\/metadata//" /tmp/ramdisk/fstab.angler
fi
if  grep -qr verify=/dev/block/platform/soc.0/f9824900.sdhci/by-name/metadata /tmp/ramdisk/fstab.angler; then
   sed -i "s/\,verify\=\/dev\/block\/platform\/soc\.0\/f9824900\.sdhci\/by\-name\/metadata//" /tmp/ramdisk/fstab.angler
fi

rm /tmp/ramdisk/verity_key

#Start elementalx script
if [ $(grep -c "import /init.elementalx.rc" /tmp/ramdisk/init.rc) == 0 ]; then
   sed -i "/import \/init\.environ\.rc/aimport /init.elementalx.rc" /tmp/ramdisk/init.rc
fi

#Allow touchboost for apps
if [ $(grep -c "touchboost" /tmp/ramdisk/file_contexts) == 0 ]; then
   echo "/sys/module/msm_performance/parameters/touchboost     u:object_r:sysfs:s0" >> /tmp/ramdisk/file_contexts
fi

#To utilize all 4 cores
rm /tmp/ramdisk/init.angler.rc
cp /tmp/init.angler.rc /tmp/ramdisk/init.angler.rc
chmod 750 /tmp/ramdisk/init.angler.rc

#copy elementalx scripts
cp /tmp/init.elementalx.rc /tmp/ramdisk/init.elementalx.rc
chmod 0750 /tmp/ramdisk/init.elementalx.rc

find . | cpio -o -H newc | gzip > /tmp/boot.img-ramdisk.gz
rm -r /tmp/ramdisk
