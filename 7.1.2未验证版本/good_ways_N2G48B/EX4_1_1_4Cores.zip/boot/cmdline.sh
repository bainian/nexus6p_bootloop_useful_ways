#!/sbin/sh

val1=$(cat /tmp/aroma/cpu53.prop | cut -d '=' -f2)

  case $val1 in
	1)
	  cpu_max_a53="cpu_max_a53=1708800"
	  ;;
	2)
	  cpu_max_a53="cpu_max_a53=1632000"
	  ;;
	3)
	  cpu_max_a53="cpu_max_a53=1555200"
	  ;;
	4)
	  cpu_max_a53="cpu_max_a53=1478400"
	  ;;
	5)
	  cpu_max_a53="cpu_max_a53=1248000"
	  ;;
  esac

val2=$(cat /tmp/aroma/cpu57.prop | cut -d '=' -f2)

  case $val2 in
	1)
	  cpu_max_a57="cpu_max_a57=2054400"
	  ;;
	2)
	  cpu_max_a57="cpu_max_a57=2016000"
	  ;;
	3)
	  cpu_max_a57="cpu_max_a57=1958400"
	  ;;
	4)
	  cpu_max_a57="cpu_max_a57=1824000"
	  ;;
	5)
	  cpu_max_a57="cpu_max_a57=1728000"
	  ;;
  	6)
	  cpu_max_a57="cpu_max_a57=1536000"
	  ;;
	7)
	  cpu_max_a57="cpu_max_a57=1248000"
	  ;;
  esac

echo "cmdline = androidboot.hardware=angler androidboot.console=ttyHSL0 msm_rtb.filter=0x37 ehci-hcd.park=3 lpm_levels.sleep_disabled=1 boot_cpus=0-3 maxcpus=4" $cpu_max_a53 $cpu_max_a57 > /tmp/cmdline.cfg

